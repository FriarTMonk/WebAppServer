Bible SuperSearch Bible Export

JSON
JavaScript Object Notation


These Bibles are legally shareable and reshareable for non-commercial purposes.  Please share them with others.

Please see the copyright statement on each Bible for more information.

These files are provided as-is and without warranty.


Index of Bibles Included: 

File                                        Bible
================================================================================================================================================================


EN-English
--------------------------------------------------------------------------------------------------------------------------------------------
* asv.json -------------------------------- American Standard Version (1901)
* asvs.json ------------------------------- American Standard Version w Strong's
* kjv_strongs.json ------------------------ KJV with Strongs (1611 / 1769)


GRC-Κοινη   (Greek)
--------------------------------------------------------------------------------------------------------------------------------------------
* tr.json --------------------------------- Textus Receptus NT (1550 / 1884)


HE-עברית   (Hebrew)
--------------------------------------------------------------------------------------------------------------------------------------------
* wlc.json -------------------------------- WLC


